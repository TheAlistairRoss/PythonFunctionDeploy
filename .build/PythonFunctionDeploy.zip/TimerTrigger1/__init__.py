import logging

def main(trigger):
    logging.info("RunningScript")
  
   

if __name__ == '__main__':
    main()