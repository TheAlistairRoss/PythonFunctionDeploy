import numpy as np
import logging

def main(trigger):
    a = np.arange(1,11,1)
    logging.info(a)
  
   

if __name__ == '__main__':
    main()